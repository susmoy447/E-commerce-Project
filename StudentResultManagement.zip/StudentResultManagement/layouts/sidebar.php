
<h1><a href="index.php" class="logo">Project Name</a></h1>
<ul class="list-unstyled components mb-5">
    <li class="active">
        <a href="index.php"><span class="fa fa-home mr-3"></span> Homepage</a>
    </li>
    <li class="active">
        <a href="student-result.php"><span class="fa fa-user mr-3"></span> Students Result List</a>
    </li>
    <li class="active">
        <a href="logout.php"><span class="fa fa-sign-out mr-3"></span> Logout</a>
    </li>

</ul>

</nav>
